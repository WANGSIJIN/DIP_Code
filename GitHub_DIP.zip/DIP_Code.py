#coding:utf8
import cv2 as cv
import numpy as np
from copy import deepcopy
from PIL import Image, ImageDraw,ImageFont
from pylab import *
import imutils
import matplotlib.pyplot as graph
from numpy import fft
import math

save_path = "change/change.png"

#图片写入文字
def Drawworld(img,text,p_x,p_y,font_type,font_size,bold,color):

    
    pos = (p_x,p_y)
    cv.putText(img,text,pos, font_type, font_size, color,bold)
    cv.imwrite(save_path, img)


#空间转换
def color_space(img,c_type):
    if c_type == 1:
        out = cv.cvtColor(img, cv.COLOR_BGR2HSV)
    elif c_type == 2:
        out = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    elif c_type == 3:
        out = cv.cvtColor(img, cv.COLOR_BGR2BGRA)
    elif c_type == 4:
        out = cv.cvtColor(img, cv.COLOR_BGR2HLS)
    elif c_type == 5:
        out = cv.cvtColor(img, cv.COLOR_BGR2YUV)

    cv.imwrite(save_path, out)
    return out

#FFT变换

def FFT(img):
    img = img[:,:,0]                #灰度
    f = np.fft.fft2(img)
    fshift = np.fft.fftshift(f)
    out = 20*np.log(np.abs(fshift))
    cv.imwrite(save_path, out)
    
#DCT变换
def DCT(img_path):
    img = cv.imread(img_path,0)
    img = img.astype(np.float32)
    out = cv.dct(img)
    cv.imwrite(save_path, out)
    

#直方图线性拉伸
def Linear_hist(img):
    def linlamda(img):                        #y = ax+b
        # 计算原图中出现的最小灰度级和最大灰度级
        # 使用函数计算
        Imin, Imax = cv.minMaxLoc(img)[:2]
        # 使用numpy计算
        # Imax = np.max(img)
        # Imin = np.min(img)
        Omin, Omax = 0, 255
        # 计算a和b的值
        a = float(Omax - Omin) / (Imax - Imin)

        b = Omin - a * Imin
        out = a * img + b
        out = out.astype(np.uint8)
        return out
    if (len(img.shape) == 2):                 #判断是否为灰度图像

        out = linlamda(img)



    else:                                   #不是灰度图像，则分别对三个通道进行线性变换
        b = img[:,:,0]
        g = img[:,:,1]
        r = img[:,:,2]

        b1 = linlamda(b)
        g1 = linlamda(g)
        r1 = linlamda(r)

        out =cv.merge([b1,g1,r1])                   #三个通道合并

    cv.imwrite(save_path, out)


    return out


#非线性拉伸
def Ninear_hist(img):
    
   
    if (len(img.shape) == 2):               #灰度图像则进行gammab变换
    
        gammab = img
        rows=img.shape[0]
        cols=img.shape[1]
        for i in range(rows):
            for j in range(cols):
                gammab[i][j]=3*pow(gammab[i][j],0.8)

        out = gammab



    else:                                        #同理不为灰度图像，对三个通道进行gammab函数变换
        b = img[:,:,0]
        g = img[:,:,1]
        r = img[:,:,2]

        gammab=b
        rows=img.shape[0]
        cols=img.shape[1]
        for i in range(rows):
            for j in range(cols):
                gammab[i][j]=3*pow(gammab[i][j],0.8)

        gammag=g
        rows=img.shape[0]
        cols=img.shape[1]
        for i in range(rows):
            for j in range(cols):
                gammag[i][j]=3*pow(gammag[i][j],0.8)

        gammar=r
        rows=img.shape[0]
        cols=img.shape[1]
        for i in range(rows):
            for j in range(cols):
                gammar[i][j]=3*pow(gammar[i][j],0.8)

        

        b = gammab
        g = gammag
        r = gammar

        out =cv.merge([b,g,r])

    cv.imwrite(save_path, out)
    return out


#自适应均衡
def adaptive_equalization(img):
    clahe = cv.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))    #自适应均衡
    
    if (len(img.shape) == 2):
    
        out = clahe.apply(img)
        
    else:
        b = img[:,:,0]
        g = img[:,:,1]
        r = img[:,:,2]

        b1 = clahe.apply(b)
        g1 = clahe.apply(g)
        r1 = clahe.apply(r)

        out =cv.merge([b1,g1,r1])

    cv.imwrite(save_path, out)

    return out



#全局均衡
def global_equalization(img):
    
    if (len(img.shape) == 2):
    
        out = cv.equalizeHist(img)
        
    else:
        b = img[:,:,0]
        g = img[:,:,1]
        r = img[:,:,2]

        b1 = cv.equalizeHist(b)                             #直方图均衡
        g1 = cv.equalizeHist(g)
        r1 = cv.equalizeHist(r)

        out =cv.merge([b1,g1,r1])

    cv.imwrite(save_path, out)

    return out

#均值平滑
def ave_blur(img):
    
    if (len(img.shape) == 2):

        gam = cv.blur(img, (5, 5))
        out = img
        rows=img.shape[0]
        cols=img.shape[1]
        for i in range(rows):
            for j in range(cols):
                out[i][j] = gam[i][j]

    else:
        b = img[:,:,0]
        g = img[:,:,1]
        r = img[:,:,2]

        gam = cv.blur(b, (5, 5))
        b1 = b
        rows=img.shape[0]
        cols=img.shape[1]
        for i in range(rows):
            for j in range(cols):
                b1[i][j] = gam[i][j]

        gam = cv.blur(g, (5, 5))
        g1 = g
        rows=img.shape[0]
        cols=img.shape[1]
        for i in range(rows):
            for j in range(cols):
                g1[i][j] = gam[i][j]

        gam = cv.blur(r, (5, 5))
        r1 = r
        rows=img.shape[0]
        cols=img.shape[1]
        for i in range(rows):
            for j in range(cols):
                r1[i][j] = gam[i][j]

        out =cv.merge([b1,g1,r1])

    cv.imwrite(save_path, out)

    return out

#高斯平滑
def gau_blur(img):
    
    if (len(img.shape) == 2):
    
        out = cv.GaussianBlur(img, (7, 7), 10)
        
    else:
        b = img[:,:,0]
        g = img[:,:,1]
        r = img[:,:,2]

        b1 = cv.GaussianBlur(b, (7, 7), 10)
        g1 = cv.GaussianBlur(g, (7, 7), 10)
        r1 = cv.GaussianBlur(r, (7, 7), 10)

        out =cv.merge([b1,g1,r1])
    cv.imwrite(save_path, out)
    return out

#中值平滑
def mid_blur(img):
    
    if (len(img.shape) == 2):

        out = cv.medianBlur(img, 5)

    else:
        b = img[:,:,0]
        g = img[:,:,1]
        r = img[:,:,2]

        b1 = cv.medianBlur(b, 5)
        g1 = cv.medianBlur(g, 5)
        r1 = cv.medianBlur(r, 5)

        out =cv.merge([b1,g1,r1])

    cv.imwrite(save_path, out)

    return out

#锐化1
# def l_sharpen1(img):
#     kernel = np.array([[0,1,0], [1,-4,1], [0,1,0]])
#     out = cv.filter2D(img,-1, kernel=kernel)
#     cv.imwrite(save_path, out)
#     return out
#
# #锐化2
# def l_sharpen2(img):
#     kernel = np.array([[-1,-1,-1], [-1,8,-1], [-1,-1,-1]])
#     out = cv.filter2D(img,-1, kernel=kernel)
#     cv.imwrite(save_path, out)
#     return out

#锐化3
def l_sharpen3(img):
    # kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
    # out = cv.filter2D(img,-1, kernel=kernel)
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]], np.float32)  # 实现锐化处理，提高图像的对比度，提高立体感，轮廓更加清晰
    out = cv.filter2D(img, -1, kernel)
    cv.imwrite(save_path, out)
    return out

#美颜
def makeup(image,value):

    b = image[:,:,0]
    g = image[:,:,1]
    r = image[:,:,2]

    b2 = cv.medianBlur(b, 5)
    g2 = cv.medianBlur(g, 5)
    r2 = cv.medianBlur(r, 5)
    
    image=cv.merge([b2,g2,r2])
    #kernel = np.array([[-1,-1,-1], [-1,9,-1], [-1,-1,-1]])
    #image = cv2.filter2D(image,-1, kernel=kernel)

    value = int(value/2)
    out = cv.bilateralFilter(image,value,value * 2,int(value / 2))
    cv.imwrite(save_path, out)
    return out
    
   

#图像旋转

def rotate(image, angle):
    
    (h, w) = image.shape[:2]
    center = (w / 2, h / 2)
    Roa = cv.getRotationMatrix2D(center, angle, 1.0)
    out = cv.warpAffine(image, Roa, (w, h))
    cv.imwrite(save_path, out)
    return out

#图像缩放
def changescale(image,size):
    b = image[:,:,0]
    g = image[:,:,1]
    r = image[:,:,2]

    b2 = cv.resize(b, (0, 0), fx=size, fy=size, interpolation=cv.INTER_NEAREST)
    g2 = cv.resize(g, (0, 0), fx=size, fy=size, interpolation=cv.INTER_NEAREST)
    r2 = cv.resize(r, (0, 0), fx=size, fy=size, interpolation=cv.INTER_NEAREST)
    
    out=cv.merge([b2,g2,r2])
    
    
    cv.imwrite(save_path, out)
    return out

#图像翻转
# def myflip(image , direction):
#     out = cv.flip(image, direction)
#     cv.imwrite(save_path, out)
#     return out

#图像投影矫正
def correct(image):
    pts1 = np.float32([[158, 25], [267, 136], [58, 66], [144, 212]])
    # 变换后分别在左上、右上、左下、右下四个点
    pts2 = np.float32([[0, 0], [320, 0], [0, 200], [320, 200]])

    # 生成透视变换矩阵
    M = cv.getPerspectiveTransform(pts1, pts2)
    # 进行透视变换
    dst = cv.warpPerspective(image, M, (320, 200))

    out = dst
    cv.imwrite(save_path, out)
    return out


#模糊消除          spoe.jpg文件
def removefuzzy(image):
    def motion_process(image_size, motion_angle):
        PSF = np.zeros(image_size)

        center_position = (image_size[0] - 1) / 2

        slope_tan = math.tan(motion_angle * math.pi / 180)
        slope_cot = 1 / slope_tan
        if slope_tan <= 1:
            for i in range(15):
                offset = round(i * slope_tan)  # ((center_position-i)*slope_tan)
                PSF[int(center_position + offset - 10), int(center_position - offset + 123)] = 2
            return PSF / PSF.sum()  # 对点扩散函数进行归一化亮度
        else:
            for i in range(15):
                offset = round(i * slope_cot)
                PSF[int(center_position - offset - 10), int(center_position + offset + 123)] = 2
            return PSF / PSF.sum()

    def wiener(input, PSF, eps, K=0.02):  # 维纳滤波，K=0.01
        input_fft = fft.fft2(input)
        PSF_fft = fft.fft2(PSF) + eps
        PSF_fft_1 = np.conj(PSF_fft) / (np.abs(PSF_fft) ** 2 + K)
        result = fft.ifft2(input_fft * PSF_fft_1)
        result = np.abs(fft.fftshift(result))
        return result

    image = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
    img_h = image.shape[0]
    img_w = image.shape[1]

    PSF = motion_process((img_h, img_w), 30)
    result = wiener(image, PSF, 1e-3)  # 逆滤波
    cv.imwrite(save_path, result)
    return result


#图像拼接
def conectImage(img1, img2):

    b1 = img1[:,:,0]
    g1 = img1[:,:,1]
    r1 = img1[:,:,2]

    h,w,_ = img1.shape

    b2 = img2[:,:,0]
    g2 = img2[:,:,1]
    r2 = img2[:,:,2]

    b2 = cv.resize(b2, (w, h), interpolation=cv.INTER_CUBIC)
    g2 = cv.resize(g2, (w, h), interpolation=cv.INTER_CUBIC)
    r2 = cv.resize(r2, (w, h), interpolation=cv.INTER_CUBIC)

    img2 = cv.merge([b2,g2,r2])
   
    out = Image.new('RGBA',(2*w,h))
    img1 = Image.fromarray(cv.cvtColor(img1, cv.COLOR_BGR2RGB))
    img2 = Image.fromarray(cv.cvtColor(img2, cv.COLOR_BGR2RGB))
    out.paste(img1,(0,0))
    out.paste(img2,(w,0))
    out = cv.cvtColor(np.asarray(out),cv.COLOR_RGB2BGR)
    cv.imwrite(save_path, out)
    return out


def back_vary(img):               #背景变换  p1.jpg

    img = cv.resize(img, None, fx=1, fy=1)
    rows, cols, channels = img.shape  # rows，cols最后一定要是前景图片的，后面遍历图片需要用到
    #cv2.imshow('img', img)
    # 转换hsv
    hsv = cv.cvtColor(img, cv.COLOR_BGR2HSV)
    # cv2.imshow('hsv', hsv)
    lower_blue = np.array([100, 100, 50])
    upper_blue = np.array([130, 255, 255])
    mask = cv.inRange(hsv, lower_blue, upper_blue)
    # cv2.imshow('Mask', mask)

    # 腐蚀膨胀
    erode = cv.erode(mask, None, iterations=1)
    # cv2.imshow('erode', erode)
    dilate = cv.dilate(erode, None, iterations=1)
    # cv2.imshow('dilate', dilate)

    #   遍历替换
    for i in range(rows):
        for j in range(cols):
            if dilate[i, j] == 255:  # 0代表黑色的点
                img[i, j] = (0, 0, 200)  # 此处替换颜色，为BGR通道
    cv.imwrite(save_path, img)
    return img


def huantou(img1, img2):                             #换头 people_p1/p2 .jpg

    head2 = img2[15:270, 55:270]
    img1[35:290, 55:270] = head2
    cv.imwrite(save_path, img1)
    return img1

if  __name__ == "__main__":
    cv.waitKey(0)  # 等待用户操作，里面等待参数是毫秒，我们填写0，代表是永远，等待用户操作
    cv.destroyAllWindows()  # 销毁所有窗口
    
