#coding:
# tf8

from PIL import Image, ImageDraw,ImageFont
from PyQt5.QtWidgets import (QMainWindow, QMenuBar, QToolBar, QTextEdit, QAction, QApplication,
                             qApp, QMessageBox, QFileDialog,QLabel, QHBoxLayout,QGroupBox,
                             QComboBox,QGridLayout,QLineEdit,QSlider,QPushButton)
from PyQt5.QtGui import *
from PyQt5.QtGui import QPalette,QImage,QPixmap,QBrush
from PyQt5.QtCore import *
import sys
import cv2 as cv
import numpy as np
import DIP_Code as ph
import time
from pylab import *


class Window(QMainWindow):
    image = 0
    path = ' '
    makeupvalue = 25
    alpha = 0.6
    r = 0
    g = 0
    b = 0
    
    text = ' '
    p_x = 50
    p_y = 150
    fontsize = 1
    fonttype = 1
    fontbold = 1
    angle = 0
    change_path = "change/change.png"

    IMG1 = ' '
    IMG2 = 'null'
    def __init__(self):
        super(Window, self).__init__()
        #界面初始化
        self.createMenu()
        self.image_show()
        self.font_GroupBox()

        self.initUI()

    # 菜单栏
    def createMenu(self):
        # menubar = QMenuBar(self)
        menubar = self.menuBar()
        
        menu1 = menubar.addMenu("文件")
        menu1.addAction("打开")
        menu1.addAction("保存")
       

        menu2 = menubar.addMenu("原图")
        menu2.addAction("返回原图")

        

        menu3 = menubar.addMenu("基础操作")
        menu3_1 = menu3.addMenu("彩色空间转换")
        menu3_1.addAction("转HSV")
        menu3_1.addAction("转GRAY")
        menu3_1.addAction("转BGRA")
        menu3_1.addAction("转HLS")
        menu3_1.addAction("转YUV")
        menu3.addAction("FFT变换")
        menu3.addAction("DCT变换")


        menu4 = menubar.addMenu("直方图")
        menu4_1 = menu4.addMenu("拉伸")
        menu4_1.addAction("线性拉伸")
        menu4_1.addAction("非线性拉伸")
        menu4_2 = menu4.addMenu("均衡")
        menu4_2.addAction("自适应均衡")
        menu4_2.addAction("全局均衡")


        menu5 = menubar.addMenu("滤镜")
        menu5_1 = menu5.addMenu("平滑")
        menu5_1.addAction("均值模糊")
        menu5_1.addAction("高斯模糊")
        menu5_1.addAction("中值模糊")
        menu5_2 = menu5.addMenu("锐化")
        menu5_2.addAction("锐化")
        # menu5_2.addAction("锐化2")
        # menu5_2.addAction("锐化3")
        menu5.addAction("美颜")


        menu6 = menubar.addMenu("图像恢复")
        menu6_3 = menu6.addMenu("缩放")
        menu6_3.addAction("放大")
        menu6_3.addAction("缩小")
        menu6_1 = menu6.addMenu("旋转")
        menu6_1.addAction("右旋转90度")
        menu6_1.addAction("左旋转90度")
        menu6.addAction("投影矫正")
        menu6.addAction("模糊消除")


        menu7 = menubar.addMenu("图像合成")
        menu7.addAction("图像拼接")
        menu7.addAction("更换背景")
        menu7.addAction("换头")



        #发射信号绑定信号槽
        menu1.triggered[QAction].connect(self.menu1_process)
        menu2.triggered[QAction].connect(self.menu2_process)
        menu3.triggered[QAction].connect(self.menu3_process)
        menu4.triggered[QAction].connect(self.menu4_process)
        menu5.triggered[QAction].connect(self.menu5_process)
        menu6.triggered[QAction].connect(self.menu6_process)
        menu7.triggered[QAction].connect(self.menu7_process)

    #像素图显示
    def image_show(self):

        
        self.lbl = QLabel(self)
        self.lbl.setPixmap(QPixmap('E:/photoedit/change/source.png'))
        self.lbl.setAlignment(Qt.AlignCenter)                   #图像显示区，居中
        self.lbl.setGeometry(450, 35, 800, 500)
        self.lbl.setStyleSheet("border: 2px solid black")

        
    
    #工具处理布局
    def font_GroupBox(self):
        text_lbl = QLabel("输入文字:",self)
        text_lbl.setGeometry(25, 35, 50, 30)
        text_text = QLineEdit(self)
        text_text.setGeometry(90, 35, 250, 30)

        xy_lbl = QLabel("输入坐标:",self)
        xy_lbl.setGeometry(25, 70, 50, 30)
        x_text = QLineEdit(self)
        x_text.setGeometry(90, 70, 30, 30)
        y_text = QLineEdit(self)
        y_text.setGeometry(130, 70, 30, 30)
        xy_btn = QPushButton('坐标确认', self)
        xy_btn.setGeometry(190, 70, 60, 30)


        size_lbl = QLabel("字体大小:",self)
        size_lbl.setGeometry(25, 105, 50, 30)
        size_combo = QComboBox(self)
        size_combo.addItem("1")
        size_combo.addItem("2")
        size_combo.addItem("3")
        size_combo.addItem("4")
        size_combo.addItem("5")
        size_combo.addItem("6")
        size_combo.addItem("7")
        size_combo.setGeometry(90, 105, 50, 30)

        bold_lbl = QLabel("字体厚度:",self)
        bold_lbl.setGeometry(170, 105, 50, 30)
        bold_combo = QComboBox(self)
        bold_combo.addItem("1")
        bold_combo.addItem("2")
        bold_combo.addItem("3")
        bold_combo.addItem("4")
        bold_combo.addItem("5")
        bold_combo.addItem("6")
        bold_combo.addItem("7")
        bold_combo.setGeometry(235, 105, 50, 30)


        color_lbl = QLabel("字体颜色:",self)
        color_lbl.setGeometry(25, 140, 50, 30)
        color_combo = QComboBox(self)
        color_combo.addItem("黑")
        color_combo.addItem("白")
        color_combo.addItem("红")
        color_combo.addItem("橙")
        color_combo.addItem("黄")
        color_combo.addItem("蓝")
        color_combo.addItem("绿")
        color_combo.addItem("紫")
        color_combo.setGeometry(90, 140, 50, 30)

        type_lbl = QLabel("字体样式:",self)
        type_lbl.setGeometry(170, 140, 50, 30)
        type_combo = QComboBox(self)
        type_combo.addItem("1")
        type_combo.addItem("2")
        type_combo.addItem("3")
        type_combo.addItem("4")
        type_combo.addItem("5")
        type_combo.addItem("6")
        type_combo.addItem("7")
        type_combo.setGeometry(235, 140, 50, 30)

        surebtn = QPushButton('旋转确认', self)
        surebtn.setCheckable(True)
        surebtn.setGeometry(200, 205, 60, 30)

        angle_lbl = QLabel("图像旋转角度:",self)
        angle_lbl.setGeometry(25, 200, 80, 40)
        angle_text = QLineEdit(self)
        angle_text.setGeometry(110, 200, 65, 40)

        makeup_lbl = QLabel("美颜效果:",self)
        makeup_lbl.setGeometry(25, 300, 100, 40)
        sld = QSlider(Qt.Horizontal, self)
        sld.setFocusPolicy(Qt.NoFocus)
        sld.setGeometry(50, 350, 200, 30)

        # 信号与槽连接   文本框输入连接
        text_text.textChanged[str].connect(self.input_text)
        x_text.textChanged[str].connect(self.input_px)
        y_text.textChanged[str].connect(self.input_py)
        xy_btn.clicked[bool].connect(self.xy_press)
        size_combo.activated[str].connect(self.inputsize)
        bold_combo.activated[str].connect(self.inputbold)
        type_combo.activated[str].connect(self.inputtype)
        color_combo.activated[str].connect(self.inputcolor)
        angle_text.textChanged[str].connect(self.input_angle)       #输入旋转角度
        surebtn.clicked[bool].connect(self.presssure)              #旋转确认
        sld.valueChanged[int].connect(self.makeupValue)            #美颜滑条


        
        



    def initUI(self):
        self.setGeometry(50, 50, 1300, 550)
        self.setWindowTitle('DIP_Course')
        self.setWindowIcon(QIcon(r"E:\DIPcourse\images\lena.jpg"))
        palette = QPalette()
        palette.setColor(self.backgroundRole(), QColor(255,255,255))
        self.setPalette(palette)
        self.show()


    #菜单1处理
    def menu1_process(self,q):
        if q.text() == "打开":
            
            choose = 1

        else:
            choose = 2

        if choose == 1:
            self.path = QFileDialog.getOpenFileName(self, '打开文件', 'E:/DIPcourse/images/',"All Files (*);;(*.bmp);;(*.tif);;(*.png);;(*.jpg)")
            self.image = cv.imread(self.path[0])
            self.IMG1 = self.image
            self.lbl.setPixmap(QPixmap(self.path[0]))

        else:
            save_path = QFileDialog.getSaveFileName(self, '保存文件', 'E:/',"All Files (*);;(*.bmp);;(*.tif);;(*.png);;(*.jpg)")
            cv.imwrite(save_path[0],self.image)

    #菜单2处理
    def menu2_process(self,q):
        self.image = cv.imread(self.path[0])
        self.lbl.setPixmap(QPixmap(self.path[0]))
        

    #菜单3处理
    def menu3_process(self,q):
        if q.text() == "转HSV":
            self.image = ph.color_space(self.image,1)
        elif q.text() == "转GRAY":
            self.image = ph.color_space(self.image,2)
        elif q.text() == "转BGRA":
            self.image = ph.color_space(self.image,3)
        elif q.text() == "转HLS":
            self.image = ph.color_space(self.image,4)
        elif q.text() == "转YUV":
            self.image = ph.color_space(self.image,5)
        elif q.text() == "FFT变换":
            ph.FFT(self.image)
        elif q.text() == "DCT变换":
            ph.DCT(self.path[0])

        self.lbl.setPixmap(QPixmap(self.change_path))


    #菜单4处理
    def menu4_process(self,q):
        if q.text() == "线性拉伸":
            
            self.image = ph.Linear_hist(self.image)
            self.lbl.setPixmap(QPixmap(self.change_path))
            plt.subplot(1, 1, 1)
            plt.hist(self.image.ravel(), 256, [0, 256]), plt.title("xianxing")
            plt.show()
        
        elif q.text() == "自适应均衡":
            self.image = ph.adaptive_equalization(self.image)
            self.lbl.setPixmap(QPixmap(self.change_path))
            plt.subplot(1, 1, 1)
            plt.hist(self.image.ravel(), 256, [0, 256]), plt.title("zishiyingjunheng")
            plt.show()
        elif q.text() == "全局均衡":
            self.image = ph.global_equalization(self.image)
            self.lbl.setPixmap(QPixmap(self.change_path))
            plt.subplot(1, 1, 1)
            plt.hist(self.image.ravel(), 256, [0, 256]), plt.title("quanjujunheng")
            plt.show()
        elif q.text() == "非线性拉伸":
            self.image = ph.Ninear_hist(self.image)
            self.lbl.setPixmap(QPixmap(self.change_path))
            plt.subplot(1, 1, 1)
            plt.hist(self.image.ravel(), 256, [0, 256]), plt.title("feixianxing")
            plt.show()





    #菜单5处理
    def menu5_process(self,q):
        if q.text() == "均值模糊":
            
            self.image = ph.ave_blur(self.image)
        
        elif q.text() == "高斯模糊":
            self.image = ph.gau_blur(self.image)
        elif q.text() == "中值模糊":
            self.image = ph.mid_blur(self.image)
        elif q.text() == "锐化":
            self.image = ph.l_sharpen3(self.image)
        elif q.text() == "美颜":
            ph.makeup(self.image,self.makeupvalue)


        self.lbl.setPixmap(QPixmap(self.change_path))


    #菜单6处理
    def menu6_process(self,q):
        if q.text() == "放大":
            self.image = ph.changescale(self.image,1.1)
            self.lbl.setPixmap(QPixmap(self.change_path))
        elif q.text() == "缩小":
            self.image = ph.changescale(self.image,0.9)
            self.lbl.setPixmap(QPixmap(self.change_path))
        elif q.text() == "右旋转90度":
            self.image = ph.rotate(self.image,-90)
            self.lbl.setPixmap(QPixmap(self.change_path))
        elif q.text() == "左旋转90度":
            self.image = ph.rotate(self.image,90)
            self.lbl.setPixmap(QPixmap(self.change_path))
        elif q.text() == "投影矫正":
            self.image = ph.correct(self.image)
            self.lbl.setPixmap(QPixmap(self.change_path))


        elif q.text() == "模糊消除":
            self.image = ph.removefuzzy(self.image)
            self.lbl.setPixmap(QPixmap(self.change_path))


    #菜单7处理
    def menu7_process(self,q):



        if q.text() == "图像拼接":
            img2_path = QFileDialog.getOpenFileName(self, '打开文件', 'E:/DIPcourse/images/',
                                                    "All Files (*);;(*.bmp);;(*.tif);;(*.png);;(*.jpeg);;(*.jpg)")
            self.IMG2 = cv.imread(img2_path[0])
            self.image = ph.conectImage(self.image,self.IMG2)
        elif q.text() == "更换背景":
            self.image = ph.back_vary(self.image)
        elif q.text() == "换头":
            img2_path = QFileDialog.getOpenFileName(self, '打开文件', 'E:/DIPcourse/images/',
                                                    "All Files (*);;(*.bmp);;(*.tif);;(*.png);;(*.jpeg);;(*.jpg)")
            self.IMG2 = cv.imread(img2_path[0])
            self.image = ph.huantou(self.image,self.IMG2)
           

        self.lbl.setPixmap(QPixmap(self.change_path))


  #文本输入处理
    def input_text(self,text):
        self.text = text
        ph.Drawworld(self.image,self.text,self.p_x,self.p_y,self.fonttype,self.fontsize,self.fontbold,(self.r,self.g,self.b))
        self.lbl.setPixmap(QPixmap(self.change_path))

    #X轴输入处理
    def input_px(self,text):
        
        self.p_x = int(text)
        
    #Y轴输入处理
    def input_py(self,text):
        
        self.p_y = int(text)

    def xy_press(self):
        ph.Drawworld(self.image,self.text,self.p_x,self.p_y,self.fonttype,self.fontsize,self.fontbold,(self.r,self.g,self.b))
        self.lbl.setPixmap(QPixmap(self.change_path))
        
    #字体大小
    def inputsize(self,text):
        if text == "1":
            self.fontsize = 1
        elif text == "2":
            self.fontsize = 2
        elif text == "3":
            self.fontsize = 3
        elif text == "4":
            self.fontsize = 4
        elif text == "5":
            self.fontsize = 5
        elif text == "6":
            self.fontsize = 6
        elif text == "7":
            self.fontsize = 7

        ph.Drawworld(self.image,self.text,self.p_x,self.p_y,self.fonttype,self.fontsize,self.fontbold,(self.r,self.g,self.b))
        self.lbl.setPixmap(QPixmap(self.change_path))

    #字体厚度
    def inputbold(self,text):
        if text == "1":
            self.fontbold = 1
        elif text == "2":
            self.fontbold = 2
        elif text == "3":
            self.fontbold = 3
        elif text == "4":
            self.fontbold = 4
        elif text == "5":
            self.fontbold = 5
        elif text == "6":
            self.fontbold = 6
        elif text == "7":
            self.fontbold = 7

        ph.Drawworld(self.image,self.text,self.p_x,self.p_y,self.fonttype,self.fontsize,self.fontbold,(self.r,self.g,self.b))
        self.lbl.setPixmap(QPixmap(self.change_path))

    #字体样式
    def inputtype(self,text):
        if text == "1":
            self.fonttype = 1
        elif text == "2":
            self.fonttype = 2
        elif text == "3":
            self.fonttype = 3
        elif text == "4":
            self.fonttype = 4
        elif text == "5":
            self.fonttype = 5
        elif text == "6":
            self.fonttype = 6
        elif text == "7":
            self.fonttype = 7

        ph.Drawworld(self.image,self.text,self.p_x,self.p_y,self.fonttype,self.fontsize,self.fontbold,(self.r,self.g,self.b))
        self.lbl.setPixmap(QPixmap(self.change_path))

    #字体颜色
    def inputcolor(self,text):
        if text == "黑":
            self.r = 0
            self.g = 0
            self.b = 0
            
        elif text == "白":
            self.r = 255
            self.g = 255
            self.b = 255
            
        elif text == "红":
            self.r = 0
            self.g = 0
            self.b = 255
            
        elif text == "橙":
            self.r = 0
            self.g = 140
            self.b = 255
            
        elif text == "黄":
            self.r = 0
            self.g = 255
            self.b = 255
            
        elif text == "蓝":
            self.r = 255
            self.g = 0
            self.b = 0
            
        elif text == "绿":
            self.r = 0
            self.g = 255
            self.b = 0
            
        elif text == "紫":
            self.r = 21
            self.g = 0
            self.b = 148


        ph.Drawworld(self.image,self.text,self.p_x,self.p_y,self.fonttype,self.fontsize,self.fontbold,(self.r,self.g,self.b))
        self.lbl.setPixmap(QPixmap(self.change_path))

    #选装角处理
    def input_angle(self,text):
        self.angle = str(text)
        self.angle = int(self.angle)

    #旋转确认按钮
    def presssure(self):
        self.image = ph.rotate(self.image,self.angle)
        self.lbl.setPixmap(QPixmap(self.change_path))

    #美颜程度滑条
    def makeupValue(self,value):
        
        self.makeupvalue = int(value)
        ph.makeup(self.image,self.makeupvalue)
        self.lbl.setPixmap(QPixmap(self.change_path))


if __name__ == '__main__':
     
    app = QApplication(sys.argv)
    ex = Window()
    ex.show()
    sys.exit(app.exec_())
